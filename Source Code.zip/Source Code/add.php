<?php
session_start();
use VoiceParametrization\Views\AddingScreen;
if(!isset($_SESSION["logged_in"])) {
    header("Location: index.php");
    die();
}

if(isset($_SESSION["max_size"])&&$_SESSION["max_size"]===true)
{
    unset($_SESSION["max_size"]);
    AddingScreen::displayScreen(true,"Rozmiar pliku jest zbyt duży!");
}
elseif(isset($_SESSION["part_file_send"])&&$_SESSION["part_file_send"]===true)
{
    unset($_SESSION["part_file_send"]);
    AddingScreen::displayScreen(true,"Przesłano tylko część pliku!");
}
elseif(isset($_SESSION["no_file_send"])&&$_SESSION["no_file_send"]===true)
{
    unset($_SESSION["no_file_send"]);
    AddingScreen::displayScreen(true,"Nie przesłano pliku!");
}
elseif(isset($_SESSION["file_upload_error"])&&$_SESSION["file_upload_error"]===true)
{
    unset($_SESSION["file_upload_error"]);
    AddingScreen::displayScreen(true,"Nie udało się przesłać pliku, spróbuj ponownie!");
}
elseif(isset($_SESSION["file_type_error"])&&$_SESSION["file_type_error"]===true)
{
    unset($_SESSION["file_type_error"]);
    AddingScreen::displayScreen(true,"Nierozpoznawalny typ pliku, prześlij plik .wav!");
}
elseif(isset($_SESSION["upload_failed"])&&$_SESSION["upload_failed"]===true)
{
    unset($_SESSION["upload_failed"]);
    AddingScreen::displayScreen(true,"Nie udało się przesłać pliku, spróbuj ponownie!");
}
elseif(isset($_SESSION["pnameerror"])&&$_SESSION["pnameerror"]===true)
{
    unset($_SESSION["pnameerror"]);
    AddingScreen::displayScreen(true,"Wprowadzono złe imię lub nazwisko!");
}
else
{
	AddingScreen::displayScreen();
}

/**
* Przestrzeń nazw zawierająca widoki aplikacji.
*/
namespace VoiceParametrization\Views;
/**
* Klasa zawierająca kod html ekranu dodawania nowego nagrania.
*/
class AddingScreen{
/**
* Metoda służąca do wyświetlenia ekranu dodawania nowego nagrania, wraz z walidacją wprowadzanych danych.
*
* @param boolean $error flaga mówiąca, czy należy wyświetlić jeden z błędów logowania, domyślnie ustawiona na false
* @param string $errorMessage tekst wiadomości błedu (jeśli jakiś należy wyświetlić). Domyślna wartość to pusty string
*/
    public static function displayScreen($error = false, $errorMessage = ""){
        echo'
        <html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Dodaj nagranie - Parametryzacja głosu</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Footer-Dark.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button{
            -webkit-appearance: none;
            margin:0;
        }

        input[type=number]{
            -moz-appearance: : textfield;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-dark navbar-expand-md bg-dark navigation-clean">
        <div class="container"><a class="navbar-brand">Parametryzacja głosu</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse"
                id="navcol-1">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="add.php">Dodaj nagranie</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="data.php">Tabela parametrów</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="logout.php">Wyloguj się</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="contact-clean">';
    if($error){
		echo'
		<div class="container">
                       <div class="alert alert-danger" style="width:98%;margin:0 auto;z-index:1000" role="alert">'.
                       $errorMessage
                       .'<button type="button" class="close" data-dismiss="alert" aria-label="Close">
                               <span aria-hidden="true">&times;</span>
                             </button>
                         </div>
                   </div>
                ';
    }
    echo'
    <div class="modal fade" id="mod" tabindex="-1" role="dialog" aria-labelledby="modLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <div class="loader"></div>
        <div clas="loader-txt">
          <p>Po kliknięciu "Dodaj" proszę czekać aż parametryzacja zostanie wykonana</p>
          <p>Zamknięcie karty spowoduje ANULOWANIE obliczeń</p>
          <p>Po ich zakończeniu nastąpi przekierowanie do Tabeli Parametrów</p>
        </div>
      </div>
    </div>
  </div>
</div>
    ';
    echo'
        <form action="parameters.php" enctype="multipart/form-data" method="POST">
            <h2 class="text-center">Dodaj nagranie</h2>
            <div class="form-group"><input class="form-control" type="text" name="name" placeholder="Imię i nazwisko" required></div>
            <div class="form-group"><input class="form-control" type="number" name="age" placeholder="Wiek" step="1" min="1" max="120" required></div>
            <div class="form-group">
                <div class="form-check form-check-inline"><input class="form-check-input" type="radio" name="plec" value="Kobieta" required><label class="form-check-label" for="formCheck-1">Kobieta</label></div>
                <div class="form-check form-check-inline"><input class="form-check-input" type="radio" name="plec" value="Mężczyzna"><label class="form-check-label" for="formCheck-2">Mężczyzna</label></div>
            </div>
            <div class="form-group"><input class="form-control" type="text" name="RBH" placeholder="Skala RBH"></div>
            <div class="form-group"><input type="file" name="recording" accept="audio/*" required></div>
            <input type="hidden" name="MAX_FILE_SIZE" value="512000" />
            <div class="form-group"><button id="submit-button" class="btn btn-info" role="button" type="submit">Dodaj</button><a class="btn btn-light" role="button" style="margin-left: 10px;" href="data.php">Wróć</a></div>
        </form>
    </div>
    <div class="footer-dark">
        <footer>
        <p style="text-align:center;">Zalogowano jako: <b>' . $_SESSION["user_name"] . '</b>, poziom uprawnień: <b>'. $_SESSION["user_role"] .'</b></p>
            <div class="container">
                <div class="row">
                    <div class="col text-center"><img src="assets/img/seal.png" style="width: 150px;"></div>
                </div>
                <p class="copyright">Aplikacja do parametryzacji głosu&nbsp;<br>stworzona przez studentów drugiego roku kierunku Informatyka&nbsp;<br>Wydziału Zastosowań Informatyki i Matematyki&nbsp;<br>Szkoły Głównej Gospodarstwa Wiejskiego w Warszawie&nbsp;<br>w ramach
                    przedmiotu Inżynieria Oprogramowania<br></p>
                <p class="copyright">SGGW © 2020</p>
            </div>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/modal.js"></script>
    <script>
    $(document).ready(function() {
        $("#mod").modal({
          backdrop: "static",
          keyboard: true,
          show: true
        });
        setTimeout(function() {
          $("#mod").modal("hide");
        }, 2750);
  });
    </script>
</body>

</html>
        ';
    }
}
?>

