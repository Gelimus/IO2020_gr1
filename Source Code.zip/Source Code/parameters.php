<?php
session_start();
include_once("./octave/OctaveController.php");
use VoiceParametrization\OctaveInterface\OctaveController;
include_once("./FileUpload.php");
use VoiceParametrization\Controllers\FileUpload;
include_once("./DBController.php");
use VoiceParametrization\Controllers\DBController;
include_once("./Cryptography.php");
use VoiceParametrization\Controllers\Cryptography;
set_time_limit(450);


$patient =  $_POST["name"];

$valname = "/^[A-ZĄĘĆŹŻÓŁŃŚ]+(([',. -][a-ząęćźżółńśA-ZĄĘĆŹŻÓŁŃŚ])?[a-ząęćźżółńśA-ZĄĘĆŹŻÓŁŃŚ]*)*$/";

if(!preg_match($valname, $patient)){
    $_SESSION["pnameerror"] = true;
    echo $patient;
    header("Location: add.php");
    die();
}

if (FileUpload::checkForUploadErrors() != false) {
    if (FileUpload::checkMIMEType() != false) {
        $db = new DBController();
        $lastId = $db->getLastRecordingId()[0];
        $uploadedRecordingName = FileUpload::uploadFile($lastId);
        if ($uploadedRecordingName == true) echo 'Udało się zapisać plik!';
        $parameters = OctaveController::getVoiceParams("/var/www/html/octave/recordings/" . $uploadedRecordingName, $lastId);
        for($i = 1; $i < count($parameters); $i++) {
            $parameters[$i] = number_format(floatval($parameters[$i]), 4);
        }
        $patient = explode(" ", $_POST["name"]);
        $patientName = $patient[0];
        $patientSurname = $patient[1];
        $patientNameEnc = Cryptography::Encrypt($patientName);
        $patientSurnameEnc = Cryptography::Encrypt($patientSurname);
        $patientAge = intval($_POST["age"]);
        $patientGender = $_POST["plec"];
        $patientInfo = array($patientNameEnc, $patientSurnameEnc, $patientGender, $patientAge);
        $rbhScale = $_POST["RBH"];
        $insertArray = array_merge($patientInfo, $parameters);
        $db->addData($insertArray);
        if(!empty($_POST["RBH"])) {
            $db->addRBH($_SESSION["user_id"], $lastId, $rbhScale);
        }
        $db = null;
        header("Location: data.php");
        die();
    } else {
        header("Location: add.php"); 
    }
} else {
    header("Location: add.php");
}
