<?php

/**
* Przestrzeń nazw zawierająca kontrolery aplikacji.
*/
namespace VoiceParametrization\Controllers;
/**
 * Klasa zawierająca metody używane do szyfrowania i odszyfrowania danych
 */
class Cryptography {


/** 
 * Metoda szyfrująca dane wejściowe.
 * @param string $input dane do zaszyfrowania
 * 
 * @return string $output dane zaszyfrowane
 */	
public static function Encrypt($input)
{
	//type of cipher 
	$cipher_type = "DES-EDE3-CBC";
	// Openssl cipher

	$options = 0; 
	
	//key for en/de cryption
	$key = "projekt_z_IO";
	
	//initialization vector for en/de cryption
	$IV = '12345678';
	
	$output = openssl_encrypt($input, $cipher_type, $key, $options, $IV);
	
	return $output;
}


/** 
 * Metoda odszyfrowująca dane wejściowe.
 * @param string $input dane do odszyfrowania
 * 
 * @return string $output dane odszyfrowane
 */		
public static function Decrypt($input)
{
	//type of cipher 
	$cipher_type = "DES-EDE3-CBC";
	// Openssl cipher

	$options = 0; 
	
	//key for en/de cryption
	$key = "projekt_z_IO";
	
	//initialization vector for en/de cryption
	$IV = '12345678';
	
	$output = openssl_decrypt($input, $cipher_type, $key, $options, $IV);
	
	return $output;
}
}
?>